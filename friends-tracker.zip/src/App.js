import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PieChart, Pie, Cell, Legend, Tooltip, ResponsiveContainer } from "recharts";

const COLORS = ["#00C49F", "#FF8042"];

export default function FriendsMarriageTracker() {
  const [friends, setFriends] = useState([
    { name: "יוסי", married: false },
    { name: "דני", married: true },
  ]);
  const [newFriend, setNewFriend] = useState("");

  const handleAddFriend = () => {
    if (!newFriend.trim()) return;
    setFriends([...friends, { name: newFriend.trim(), married: false }]);
    setNewFriend("");
  };

  const toggleMarriageStatus = (index) => {
    const updated = [...friends];
    updated[index].married = !updated[index].married;
    setFriends(updated);
  };

  const marriedCount = friends.filter((f) => f.married).length;
  const unmarriedCount = friends.length - marriedCount;

  const chartData = [
    { name: "נשואים", value: marriedCount },
    { name: "לא נשואים", value: unmarriedCount },
  ];

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      <h1 className="text-3xl font-bold text-center">מעקב סטטוס נישואין של חברים</h1>

      <Card className="shadow-xl rounded-2xl">
        <CardContent className="space-y-4 p-6">
          <h2 className="text-2xl font-semibold">הוסף חבר חדש</h2>
          <div className="flex gap-2">
            <Input
              placeholder="שם החבר"
              value={newFriend}
              onChange={(e) => setNewFriend(e.target.value)}
              className="text-right"
            />
            <Button onClick={handleAddFriend} className="rounded-2xl px-4 py-2">
              הוסף
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-xl rounded-2xl">
        <CardContent className="space-y-4 p-6">
          <h2 className="text-2xl font-semibold">רשימת חברים</h2>
          <ul className="space-y-2">
            {friends.map((friend, index) => (
              <li
                key={index}
                className="flex justify-between items-center border p-3 rounded-xl shadow-sm bg-white"
              >
                <span className="text-lg">{friend.name}</span>
                <Button
                  variant="outline"
                  onClick={() => toggleMarriageStatus(index)}
                  className={\`rounded-full px-4 \${friend.married ? "bg-green-100 text-green-800" : "bg-orange-100 text-orange-800"}\`}
                >
                  {friend.married ? "נשוי" : "לא נשוי"}
                </Button>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card className="shadow-xl rounded-2xl">
        <CardContent className="p-6">
          <h2 className="text-2xl font-semibold mb-4 text-center">התקדמות כללית</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                outerRadius={100}
                label
                dataKey="value"
              >
                {chartData.map((entry, index) => (
                  <Cell key={\`cell-\${index}\`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
